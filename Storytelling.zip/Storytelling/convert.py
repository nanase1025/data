import json

# Function to update the 'path' in the JSON file
def update_json_file(input_file, output_file, prefix):
    # Open and read the JSON file
    with open(input_file, 'r') as file:
        data = json.load(file)

    # Update the 'path' list by adding the prefix to each element
    for element in data:
        if 'path' in element:
            # 为每个路径添加前缀
            element['path'] = [prefix + p for p in element['path']]

    # Write the updated data back to a new JSON file
    with open(output_file, 'w') as file:
        json.dump(data, file, indent=4)

# Example usage
input_file = '/Users/hansonghao/Desktop/Storytelling/the_land_story/list.json'  # Replace with the actual input file path
output_file = '/Users/hansonghao/Desktop/Storytelling/the_land_story/output.json'  # Replace with the actual output file path
prefix = '/home/work/hsh/MLLM_data/Storystream/The_Land/the_land/'

update_json_file(input_file, output_file, prefix)
